#include <sys/time.h>
#include <stdio.h>

unsigned long long millis();
